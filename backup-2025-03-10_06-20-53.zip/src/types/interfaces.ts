export interface IController<T, Req = unknown, Res = unknown> {
  getById(req: Req, res: Res): Promise<void>;
  getAll(req: Req, res: Res): Promise<void>;
  create(req: Req, res: Res): Promise<void>;
  update(req: Req, res: Res): Promise<void>;
  delete(req: Req, res: Res): Promise<void>;
}

export abstract class IService<T> {
  abstract getById(id: string): Promise<T | null>;
  abstract update(id: string, data: Partial<T>): Promise<T>;
  abstract create(data: T): Promise<T>;
  abstract delete(id: string): Promise<T>;
  abstract getAll(): Promise<T[]>;
}
