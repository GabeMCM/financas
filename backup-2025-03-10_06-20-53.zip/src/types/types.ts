import {User} from "@prisma/client";
import {Expense} from "@prisma/client";
import {Transaction} from "@prisma/client";

export type UserType = User;
export type ExpensesType = Expense;
export type TransactionType = Transaction;
